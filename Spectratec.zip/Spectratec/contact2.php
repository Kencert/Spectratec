<?php
// $home = file_get_contents('http://www.tennisexplorer.com/');
// echo "$home";
if(isset($_POST['email'])){
   $first_name = $_POST['first_name']; // required
    $last_name = $_POST['last_name']; // required
    $email_from = $_POST['email']; // required
    $telephone = $_POST['telephone']; // not required
    $comments = $_POST['comments']; // required
 require 'PHPMailer/PHPMailerAutoload.php';

  
$mail = new PHPMailer();
    //$mail->SMTPDebug = 3;                               // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    //$mail -> SMTPDebug = 2;
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPSecure = 'tls';

    $mail->Username = 'landmanagement001';                 // SMTP username
    $mail->Password = 'kencert123';                           // SMTP password
    $mail->Port = 587;                                    // TCP port to connect to

    $mail->From = ($email_from);
    $mail->FromName = 'Spectratec Admin';
    $mail->addAddress($email_from);               // Name is optional
    $mail->AddReplyTo($email_from, $first_name);
    $mail->isHTML(true);                                  // Set email format to HTML

    $mail -> Subject = $telephone;
   $mail -> Body    = $comments;
    $mail -> AltBody = $comments;
    $mail ->SMTPOptions = array('ssl' => array('verify_peer' => false,'verify_peer_name' => false,'allow_self_signed' => true));
    if(!$mail -> send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail -> ErrorInfo;
        } else {
              echo 'Message has been sent to the recipient';
              echo "<script> window.open('contact.php','_self')</script>";
      
            }
}
  
?>
