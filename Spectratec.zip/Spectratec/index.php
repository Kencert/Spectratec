<?php include( 'couch/cms.php' ); ?>
<cms:template title='Index' />


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Spectratec| Home </title>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<script type="text/javascript" src="java.js"></script>

<header class = "main-header" style="margin-top: 0px; margin-left: 0px; z-index: 1; font-size: 14px; font-weight: bold;   ">
  
<img src="img/satlogo.png" style="float: left; margin-left: 10px; margin-top: 10px; width: 150px; height: 90px;" >
  
  <!-- Menu bar appearance and elements. -->

 <label for="show-menu" class="show-menu">&#9776;</label>
<input type="checkbox" id="show-menu" role="button" style="height:50px;  background-color:#f0f0ed; color: #001971; font-size: 14px; font-weight: bold; line-height: 10px;padding-right: 30px; padding-left: 30px; "  onMouseOver="this.style.backgroundColor='rgb(0, 25, 113)', this.style.color='white'"
   onMouseOut="this.style.backgroundColor='#f0f0ed',this.style.color='#001971'">
  <ul id="menu" style=" margin-top: 10px; background: #f0f0ed; text-transform: uppercase;  ">
    <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products & Solutions</a></li>
        <li><a href="contact.php">Contact Us</a></li>
    <li>
      <div class="dropdown">
<button onclick="myFunction()" class="dropbtn"  style="height:50px;  background-color:#f0f0ed; color: #001971; font-size: 14px; font-weight: bold; line-height: 10px;padding-right: 30px; padding-left: 30px; "  onMouseOver="this.style.backgroundColor='rgb(0, 25, 113)', this.style.color='white'"
   onMouseOut="this.style.backgroundColor='#f0f0ed',this.style.color='#001971'">COMPANY ￬</button>
  <div id="myDropdown" class="dropdown-content" style="line-height: 10px;">
    <a href="about.php">About Us</a>
    <a href="what.php">What we Do</a>
    <a href="#about">Overview</a>
    <a href="#about">Career</a>
    <a href="#about">Download</a>
  </div>
</div>
      
            </li>
    
        
  </ul>

  </header>
<div  style="height:450px; width:100%;
    margin-top:100px; margin-bottom: 20px; z-index: 111; ">
<?php
include 'slider.html';
 ?>
</div>


</div>


<br>
<cms:editable name='main_content' type='richtext'>
    
<p class="article">Security companies, system integrators, commercial enterprises, prefer our IP based solutions for their requirements because we provide scalable and secure options that meet their needs as well as their clients. These go a long way in addressing physical and digital threats experienced by organizations today. </p>
</cms:editable>
<!-- <div style=" background-color: #f0f0ed; font-family:serif; font-size: 25px; margin-top: -20px; " >
  <h3 >Spectratec Alarms & Telecoms Ltd</h3>
<p class="article" >
Spectratec Alarms & Telecomms Ltd., is a leading wholesale distributor of security equipment and accessories in East Africa. Headquartered in Nairobi, Kenya, the company  boasts of exponential growth over the years since establishment in 1998. Spectratec Alarms and Telecomms has since grown to be recognized as a leading player in the security industry in Kenya, East Africa and the Central Africa region alike. Main focus revolves around the supply of Intruder Alarm systems, CCTV, IP products, Access Control, Gate and door automations, Batteries, Power supply equipments, Electric and razor wire fencing and walk through and hand held detection.
</p>
</div>
<div style="margin-bottom: 10px;">
<div class="member">
    <img src="img/highrescctv.png" style=" width: 200px; margin-right: 20px; margin-left: 10px;    height: 200px;">
    <div class="name" style=" width: 307px; text-align: center;">
      <br><i><small>High Resolution CCTV Cameras</small></i>
</div>
    </div>
    <div class="member">
    <img src="img/ipsurveilance.png" style=" width: 200px; margin-right: 20px; margin-left: 50px; 
    height: 200px;">
    <div class="name" style=" width: 307px; text-align: center;">
      <br><i><small>IP surveilance Systems</small></i>
  </div>
</div>
  <div class="member">
    <img src="img/digivideorec.png" style=" width: 200px; margin-right: 20px; margin-left: 50px; 
    height: 200px;">
  <div class="name" style=" width: 307px; text-align: center;">
      <br><i><small>Digital Video Recorders</small></i>
</div>    
    </div>
    <div class="member">
    <img src="img/accesscont.png" style=" width: 200px; margin-right: 20px; margin-left: 10px; 
    height: 200px;">
   <div class="name" style=" width: 307px; text-align: center;">
      <br><i><small>Access Controls & Time Attendance</small></i>
</div>   </div>
</div> -->
<div class="footer"  style="bottom: 20px;  right: 0px; font-size: 20px; width: 100%;  background-color: #f0f0ed;  text-align: center; z-index: 4;  margin-top:20px;   color: black;">
           © Copyright 2018. Spectratec Alarms. <br> All Rights Reserved.<br>
         
 </div>
 </body>
 
 </html>

 
<?php COUCH::invoke(); ?>