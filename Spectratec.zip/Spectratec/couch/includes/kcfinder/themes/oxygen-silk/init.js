// If this file exists in theme directory, it will be loaded in <head> section

var imgLoading = new Image();
imgLoading.src = 'themes/oxygen-silk/img/loading.gif';
