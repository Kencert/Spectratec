<html>
<?php
$web = file_get_contents("https://www.betpawa.co.ke");
echo "$web";
?>
</html>