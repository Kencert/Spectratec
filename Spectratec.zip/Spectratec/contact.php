<?php include( 'couch/cms.php' ); ?>
<cms:template title='Contact Us' />

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title> Spectratec| Contact Us </title>
<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<script type="text/javascript" src="java.js"></script>

<header class = "main-header" style="margin-top: 0px; margin-left: 0px; z-index: 1; font-size: 14px; font-weight: bold;   ">
  
<img src="img/satlogo.png" style="float: left; margin-left: 10px; margin-top: 10px; width: 150px; height: 90px;" >
  
  <!-- Menu bar appearance and elements. -->

 <label for="show-menu" class="show-menu">&#9776;</label>
<input type="checkbox" id="show-menu" role="button" style="height:50px;  background-color:#f0f0ed; color: #001971; font-size: 14px; font-weight: bold; line-height: 10px;padding-right: 30px; padding-left: 30px; "  onMouseOver="this.style.backgroundColor='rgb(0, 25, 113)', this.style.color='white'"
   onMouseOut="this.style.backgroundColor='#f0f0ed',this.style.color='#001971'">
  <ul id="menu" style=" margin-top: 10px; background: #f0f0ed; text-transform: uppercase;  ">
    <li><a href="index.php">Home</a></li>
          <li><a href="products.php">Products & Solutions</a></li>
        <li><a href="contact.php">Contact Us</a></li>
    <li>
      <div class="dropdown">
<button onclick="myFunction()" class="dropbtn"  style="height:50px;  background-color:#f0f0ed; color: #001971; font-size: 14px; font-weight: bold; line-height: 10px;padding-right: 30px; padding-left: 30px; "  onMouseOver="this.style.backgroundColor='rgb(0, 25, 113)', this.style.color='white'"
   onMouseOut="this.style.backgroundColor='#f0f0ed',this.style.color='#001971'">COMPANY ￬</button>
  <div id="myDropdown" class="dropdown-content" style="line-height: 10px;">
    <a href="about.php">About Us</a>
    <a href="what.php">What we Do</a>
    <a href="#about">Overview</a>
    <a href="#about">Career</a>
    <a href="#about">Download</a>
  </div>
</div>
      
            </li>
    
        
  </ul>

  </header>
<div style="text-align:left; width: 100%; background-color: #f0f0ed; line-height: 1.5; color: black;"><p style="font-size: 22px; margin-left: 20px; margin-top: 105px;">
    <b>Home / Contact Us</p></b></div>
<div class="article" style="background-color:white; margin-top: 10px;">
 <iframe
width="1350"
 height="450"
  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.7519680901332!2d36.84653221445909!3d-1.324710836042204!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f119541da61d3%3A0xb6a2ec54991f299e!2sPark+Side+Towers%2FAirtel!5e0!3m2!1sen!2ske!4v1516891708710" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
 


<cms:editable name='main_content' type='richtext'>
<div style="margin-top: 30px; margin-left: 20px;">
<a href="formpage.html" class="btn" >Contact Us</a></div>
<h3 style="margin-top: 50px; float: center;">HEAD OFFICE</h3>
<p style="font-size: 22px; ">
<img src="img/main.png" style="width: 2%; height: 2%">SAT CENTRE, ground floor.<br><img src="img/location.svg" style="width: 2%; height: 2%"> Behind Parkside Towers (AIRTEL) Mombasa Road.<br>          
<img src="img/main.png" style="width: 2%; height: 2%">Branch: Kenbanco Hse, 2nd Floor, Haile Selassie Ave.<br> <img src="img/mail.svg" style="width: 2%; height: 2%"> P.O. Box . 4585 - 00506 Nairobi,  Kenya.<br> 
<img src="img/phone.png" style="width: 2%; height: 2%">Tel: +254 (020) 2042 713/20 433 72/22 4492<br>/2553032/2583033/2636818.       <br>        
Fax: (20) 2249828 <br>
<img src="img/mail.svg" style="width: 2%; height: 2%"><a href="mailto: info@spectrateckenya.com">info@spectrateckenya.com</a><br>

</p></cms:editable>
<div class="footer"  style="  right: 0px;  width: 100%; font-size: 20px; background-color:#f0f0ed;  text-align: center; z-index: 4;  margin-top: 25px;  color: black; margin-bottom: 20px;">
           © Copyright 2018. Spectratec Alarms.<br> All Rights Reserved.<br>
          
          </div>
 </body>
 
 </html>
 
<?php COUCH::invoke(); ?>
<?php
// $home = file_get_contents('http://www.tennisexplorer.com/');
// echo "$home";
if(isset($_POST['submit'])){
   $first_name = $_POST['first_name']; // required
    $last_name = $_POST['last_name']; // required
    $email_from = $_POST['email']; // required
    $telephone = $_POST['telephone']; // not required
    $comments = $_POST['comments']; // required

$mail = new PHPMailer();
    //$mail->SMTPDebug = 3;                               // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail -> SMTPDebug = 2;
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPSecure = 'tls';

    $mail->Username = 'landmanagement001';                 // SMTP username
    $mail->Password = 'kencert123';                           // SMTP password
    $mail->Port = 587;                                    // TCP port to connect to

    $mail->From = ('landmanagement001@gmail.com');
    $mail->FromName = 'Lands Admin';
    $mail->addAddress($email_from);               // Name is optional

    $mail->isHTML(true);                                  // Set email format to HTML

    $mail -> Subject = $telephone;
   $mail -> Body    = $comments;
    $mail -> AltBody = $comments;
    $mail ->SMTPOptions = array('ssl' => array('verify_peer' => false,'verify_peer_name' => false,'allow_self_signed' => true));
    if(!$mail -> send()) {
        echo 'Message could not be sent.';
        echo 'Mailer Error: ' . $mail -> ErrorInfo;
        } else {
              echo 'Message has been sent to the recipient';
            }
}
  
?>